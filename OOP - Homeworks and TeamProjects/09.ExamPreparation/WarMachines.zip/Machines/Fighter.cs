﻿namespace WarMachines.Machines
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using WarMachines.Interfaces;

    public class Fighter : Machine, IFighter
    {
        public Fighter(string name, double attPoints, double defPoints, bool stealthMode)
            : base(name, 200, attPoints, defPoints)
        {
            this.StealthMode = stealthMode;
        }


        public bool StealthMode { get; private set; }
        

        public void ToggleStealthMode()
        {
            this.StealthMode = !this.StealthMode;
        }

        public override string ToString()
        {
            return base.ToString() + string.Format("\n *Stealth: {0}", this.StealthMode ? "ON" : "OFF");
        }
    }
}
