﻿namespace DocumentSystem
{
    public interface IEditable
    {
        void ChangeContent(string newContent);
    }
}
